import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
from PIL import Image, ImageTk


class Jugador:
    def __init__(self, nombre, edad, posicion):
        self.nombre = nombre
        self.edad = edad
        self.posicion = posicion

    def mostrar_info(self):
        return f"Nombre: {self.nombre}, Edad: {self.edad}, Posición: {self.posicion}"


class Equipo:
    def __init__(self, nombre, victorias=0, empates=0, derrotas=0):
        self.nombre = nombre
        self.victorias = victorias
        self.empates = empates
        self.derrotas = derrotas

    def mostrar_info(self):
        return f"Equipo: {self.nombre}\nVictorias: {self.victorias}\nEmpates: {self.empates}\nDerrotas: {self.derrotas}"


class Partido:
    def __init__(self, equipo_local, equipo_visitante, estadio, dia, hora):
        self.equipo_local = equipo_local
        self.equipo_visitante = equipo_visitante
        self.estadio = estadio
        self.dia = dia
        self.hora = hora
        self.resultado = None

    def jugar_partido(self, resultado):
        self.resultado = resultado

    def mostrar_resultado(self):
        if self.resultado:
            return f"Partido en {self.estadio.nombre} - {self.equipo_local.nombre} vs {self.equipo_visitante.nombre}: {self.resultado}"
        else:
            return f"Partido en {self.estadio.nombre} - {self.equipo_local.nombre} vs {self.equipo_visitante.nombre}: Aún no jugado"

    def mostrar_info(self):
        return f"Partido: {self.equipo_local.nombre} vs {self.equipo_visitante.nombre}\n" \
               f"Estadio: {self.estadio.nombre}\nCiudad: {self.estadio.ciudad}\nCapacidad: {self.estadio.capacidad}\n" \
               f"Día: {self.dia}\nHora: {self.hora}"


class Grupo:
    def __init__(self, nombre):
        self.nombre = nombre
        self.equipos = []

    def agregar_equipo(self, equipo):
        self.equipos.append(equipo)

    def mostrar_info(self):
        info = f"Grupo: {self.nombre}\n"
        for equipo in self.equipos:
            info += equipo.mostrar_info() + "\n"
        return info


class Estadio:
    def __init__(self, nombre, ciudad, capacidad):
        self.nombre = nombre
        self.ciudad = ciudad
        self.capacidad = capacidad

    def mostrar_info(self):
        return f"Estadio: {self.nombre}, Ciudad: {self.ciudad}, Capacidad: {self.capacidad}"


class Mundial:
    def __init__(self, root):
        self.root = root
        self.root.title("Mundial 2034")

        self.bg_color = "#0066FF"
        self.fg_color = "#1B2631"
        self.root.configure(bg=self.bg_color)

        self.equipos = []
        self.grupos = {}
        self.partidos = []

        self.frame_left = tk.Frame(self.root, bg=self.bg_color)
        self.frame_left.pack(side=tk.LEFT, fill=tk.Y)

        self.frame_right = tk.Frame(self.root, bg=self.bg_color)
        self.frame_right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        self.label_img = tk.Label(self.frame_left, bg=self.bg_color)
        self.label_img.pack()

        self.img = Image.open(r"C:\Users\cataf\Downloads\COPA.png")
        self.img = self.img.resize((200, 200), Image.LANCZOS)
        self.img = ImageTk.PhotoImage(self.img)
        self.label_img.config(image=self.img)

        self.combo = ttk.Combobox(self.frame_left, state="readonly", font=("Helvetica", 12))
        self.combo.pack(pady=20)
        self.combo.bind('<<ComboboxSelected>>', self.mostrar_info_equipo)

        self.info_text = tk.Text(self.frame_right, height=20, width=50, bg=self.bg_color, fg=self.fg_color, font=("Helvetica", 12))
        self.info_text.pack(fill=tk.BOTH, expand=True)

        self.crear_menu()

    def crear_menu(self):
        main_menu = tk.Menu(self.root)
        self.root.config(menu=main_menu)

        data_menu = tk.Menu(main_menu, tearoff=0)
        main_menu.add_cascade(label="Datos", menu=data_menu)
        data_menu.add_command(label="Cargar Datos", command=self.load_data)

        partido_menu = tk.Menu(main_menu, tearoff=0)
        main_menu.add_cascade(label="Partidos", menu=partido_menu)
        partido_menu.add_command(label="Mostrar Partidos", command=self.mostrar_partidos)

    def load_data(self):
        grupo_a = Grupo("Grupo A")
        grupo_a.agregar_equipo(Equipo("Argentina", 3, 1, 1))
        grupo_a.agregar_equipo(Equipo("Corea del Sur", 1, 3, 1))
        grupo_a.agregar_equipo(Equipo("Nigeria",1, 2, 1))
        grupo_a.agregar_equipo(Equipo("Bosnia Herzegovina",1,1,2))

        grupo_b = Grupo("Grupo B")
        grupo_b.agregar_equipo(Equipo("Alemania", 3, 1, 1))
        grupo_b.agregar_equipo(Equipo("Portugal", 1, 3, 1))
        grupo_b.agregar_equipo(Equipo("China",1, 1, 1))
        grupo_b.agregar_equipo(Equipo("Camerun",1, 0, 0))

        grupo_c = Grupo("Grupo C")
        grupo_c.agregar_equipo(Equipo("Ecuador", 3, 1, 0))
        grupo_c.agregar_equipo(Equipo("Italia", 3, 3, 1))
        grupo_c.agregar_equipo(Equipo("Australia", 1, 0, 1))
        grupo_c.agregar_equipo(Equipo("Iran",0, 1, 1))
        
        grupo_d = Grupo("Grupo C")
        grupo_d.agregar_equipo(Equipo("España", 3, 3, 1))
        grupo_d.agregar_equipo(Equipo("Uruguay", 3, 1, 0))
        grupo_d.agregar_equipo(Equipo("Estados Unidos", 1, 1, 1))
        grupo_d.agregar_equipo(Equipo("Croacia", 1, 3, 0))

        self.grupos = {"Grupo A": grupo_a, "Grupo B": grupo_b, "Grupo C": grupo_c, "Grupo D": grupo_d}

        estadio1 = Estadio("El Monumental", "Ciudad de Buenos Aires", 50000)
        estadio2 = Estadio("La Bombonera", "Buenos Aires", 70000)
        estadio3 = Estadio("Mario Alberto Kempes", "Cordoba", 57000)
        estadio4 = Estadio("Libertadores de America", "Buenos Aires", 48069)
        estadio5 = Estadio("Ciudad de la Plata", "Buenos Aires", 53000)
        estadio6 = Estadio("Marcelo Bielsa", "Santa Fe", 43000)
        self.partidos = [
            Partido(grupo_a.equipos[0], grupo_a.equipos[1], estadio1, "2034-06-10", "10:00"),
            Partido(grupo_a.equipos[0], grupo_a.equipos[2], estadio2, "2034-06-13", "14:00"),
            Partido(grupo_a.equipos[0], grupo_a.equipos[3], estadio3, "2034-06-16", "18:00"),
            Partido(grupo_a.equipos[1], grupo_a.equipos[2], estadio4, "2034-06-11", "10:00"),
            Partido(grupo_a.equipos[1], grupo_a.equipos[3], estadio5, "2034-06-14", "12:00"),
            Partido(grupo_a.equipos[2], grupo_a.equipos[3], estadio6, "2034-06-17", "14:00"),
            Partido(grupo_b.equipos[0], grupo_b.equipos[1], estadio6, "2034-06-11", "16:00"),
            Partido(grupo_b.equipos[0], grupo_b.equipos[2], estadio4, "2034-06-14", "15:00"),
            Partido(grupo_b.equipos[0], grupo_b.equipos[3], estadio1, "2034-06-17", "17:00"),
            Partido(grupo_b.equipos[1], grupo_b.equipos[2], estadio5, "2034-06-17", "10:00"),
            Partido(grupo_b.equipos[1], grupo_b.equipos[3], estadio3, "2034-06-20", "14:00"),
            Partido(grupo_b.equipos[2], grupo_b.equipos[3], estadio2, "2034-06-23", "12:00"),
            Partido(grupo_c.equipos[0], grupo_c.equipos[1], estadio6, "2034-06-21", "16:00"),
            Partido(grupo_c.equipos[0], grupo_c.equipos[2], estadio2, "2034-06-24", "12:00"),
            Partido(grupo_c.equipos[0], grupo_c.equipos[3], estadio5, "2034-06-30", "14:00"),
            Partido(grupo_c.equipos[1], grupo_c.equipos[2], estadio2, "2034-06-30", "10:00"),
            Partido(grupo_c.equipos[1], grupo_c.equipos[3], estadio1, "2034-06-25", "12:00"),
            Partido(grupo_c.equipos[2], grupo_c.equipos[3], estadio5, "2034-06-20", "15:00"),
            Partido(grupo_d.equipos[0], grupo_d.equipos[1], estadio1, "2034-06-22", "18:00"),
            Partido(grupo_d.equipos[0], grupo_d.equipos[2], estadio6, "2034-06-25", "09:00"),
            Partido(grupo_d.equipos[0], grupo_d.equipos[3], estadio3, "2034-06-28", "15:00"),
            Partido(grupo_d.equipos[1], grupo_d.equipos[2], estadio4, "2034-06-28", "19:00"),
            Partido(grupo_d.equipos[1], grupo_d.equipos[3], estadio1, "2034-07-01", "10:00"),
            Partido(grupo_d.equipos[2], grupo_d.equipos[3], estadio4, "2034-06-03", "15:00"),

            
            
        ]

        self.equipos = []
        for grupo in self.grupos.values():
            for equipo in grupo.equipos:
                self.equipos.append(equipo)

        self.combo['values'] = [equipo.nombre for equipo in self.equipos]
        self.combo.set("Seleccionar Equipo")

        self.info_text.delete(1.0, tk.END)
        self.info_text.insert(tk.END, "Datos de ejemplo cargados.\n\n")

    def mostrar_info_equipo(self, event):
        equipo_nombre = self.combo.get()
        equipo = next((equipo for equipo in self.equipos if equipo.nombre == equipo_nombre), None)
        if equipo:
            self.info_text.delete(1.0, tk.END)
            self.info_text.insert(tk.END, f"Nombre del Equipo: {equipo.nombre}\n\n")

            self.info_text.insert(tk.END, "Partidos:\n\n")
            for partido in self.partidos:
                if partido.equipo_local == equipo or partido.equipo_visitante == equipo:
                    self.info_text.insert(tk.END, partido.mostrar_info() + "\n\n")

    def mostrar_partidos(self):
        self.info_text.delete(1.0, tk.END)
        for partido in self.partidos:
            self.info_text.insert(tk.END, partido.mostrar_info() + "\n")
            self.info_text.insert(tk.END, "-" * 30 + "\n")


if __name__ == "__main__":
    root = tk.Tk()
    app = Mundial(root)
    root.mainloop()
