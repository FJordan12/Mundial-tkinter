from functools import partial
from tkinter import Image, Tk, TkVersion, ttk
import tkinter


class Mundial:
    def __init__(self, root):
        self.root = root
        self.root.title("Mundial App")

        # Configuración de colores
        self.bg_color = "#2c3e50"
        self.fg_color = "#ecf0f1"
        self.root.configure(bg=self.bg_color)

        self.equipos = []
        self.grupos = {}
        self.partidos = []

        self.frame_left = ttk._TtkCompound.Frame(self.root, bg=self.bg_color)
        self.frame_left.pack(side=ttk._TtkCompound.LEFT, fill=ttk._TtkCompound.Y)

        self.frame_right = ttk._TtkCompound.Frame(self.root, bg=self.bg_color)
        self.frame_right.pack(side=ttk._TtkCompound.RIGHT, fill=TkVersion.BOTH, expand=True)

        self.label_img = tkinter.Label(self.frame_left, bg=self.bg_color)
        self.label_img.pack()

        self.img = Image.open(r"C:\Users\cataf\Downloads\COPA.png")
        self.img = self.img.resize((200, 200), Image.LANCZOS)
        self.img = Image.PhotoImage(self.img)
        self.label_img.config(image=self.img)

        self.combo = ttk.Combobox(self.frame_left, state="readonly", font=("Helvetica", 12))
        self.combo.pack(pady=20)
        self.combo.bind('<<ComboboxSelected>>', self.mostrar_info_equipo)

        self.info_text = ttk._TtkCompound.Text(self.frame_right, height=20, width=50, bg=self.bg_color, fg=self.fg_color, font=("Helvetica", 12))
        self.info_text.pack(fill=Tk.BOTH, expand=True)

        self.crear_menu()

    def crear_menu(self):
        main_menu = ttk._TtkCompound.Menu(self.root)
        self.root.config(menu=main_menu)

        data_menu = ttk._TtkCompound.Menu(main_menu, tearoff=0)
        main_menu.add_cascade(label="Datos", menu=data_menu)
        data_menu.add_command(label="Cargar Datos", command=self.load_data)

        partido_menu = ttk._TtkCompound.Menu(main_menu, tearoff=0)
        main_menu.add_cascade(label="Partidos", menu=partido_menu)
        partido_menu.add_command(label="Mostrar Partidos", command=self.mostrar_partidos)

    def load_data(self):
        grupo_a = grupo("Grupo A")
        grupo_a.agregar_equipo(equipo("Argentina", 3, 1, 1))
        grupo_a.agregar_equipo(equipo("Brazil", 2, 2, 1))

        grupo_b = grupo("Grupo B")
        grupo_b.agregar_equipo(equipo("Colombia", 2, 0, 1))

        grupo_c = grupo("Grupo C")
        grupo_c.agregar_equipo(equipo("Alemania", 2, 1, 0))
        grupo_c.agregar_equipo(equipo("Italia", 1, 1, 1))

        self.grupos = {"Grupo A": grupo_a, "Grupo B": grupo_b, "Grupo C": grupo_c}

        estadio1 = estadio1("Estadio Monumental", "Buenos Aires", 50000)
        estadio2 = estadio2("Bombonera", "Buenos Aires", 70000)

        self.partidos = [
         partial(grupo_a.equipos[0], grupo_a.equipos[1], estadio1, "2024-06-15", "18:00"),
         partial(grupo_b.equipos[0], grupo_c.equipos[0], estadio2, "2024-06-16", "20:00")
        ]

        self.equipos = []
        for grupo in self.grupos.values():
            for equipo in grupo.equipos:
                self.equipos.append(equipo)

        self.combo['values'] = [equipo.nombre for equipo in self.equipos]
        self.combo.set("Seleccionar Equipo")

        self.info_text.delete(1.0, ttk._TtkCompound.END)
        self.info_text.insert(ttk._TtkCompound.END, "Datos de ejemplo cargados.\n\n")

    def mostrar_info_equipo(self, event):
        equipo_nombre = self.combo.get()
        equipo = next((equipo for equipo in self.equipos if equipo.nombre == equipo_nombre), None)
        if equipo:
            self.info_text.delete(1.0, ttk._TtkCompound.END)
            self.info_text.insert(ttk._TtkCompound.END, f"Nombre del Equipo: {equipo.nombre}\n\n")

            self.info_text.insert(ttk._TtkCompound.END, "Partidos:\n\n")
            for partido in self.partidos:
                if partido.equipo_local == equipo or partido.equipo_visitante == equipo:
                    self.info_text.insert(ttk._TtkCompound.END, partido.mostrar_info() + "\n\n")

    def mostrar_partidos(self):
        self.info_text.delete(1.0, ttk._TtkCompound.END)
        for partido in self.partidos:
            self.info_text.insert(ttk._TtkCompound.END, partido.mostrar_info() + "\n")
            self.info_text.insert(ttk._TtkCompound.END, "-" * 30 + "\n")